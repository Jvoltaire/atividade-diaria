package com.example.testedosistema;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    TextView textViewqtditens,textViewdesconto,textViewtotalcompra;
    Button buttoncredito,buttondebito;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        textViewqtditens = (TextView) findViewById(R.id.textViewqtditens);
        textViewdesconto = (TextView) findViewById(R.id.textViewdesconto);
        textViewtotalcompra = (TextView) findViewById(R.id.textViewtotalcompra);
        buttoncredito = (Button) findViewById(R.id.buttoncredito);
        buttondebito = (Button) findViewById(R.id.buttondebito);



        }


        }






